About the b2tob3.exe
====================
Use it at your own risk, I modified the original for my need only.

The compile script from
  https://github.com/metrey/b2tob3

The version fork from the original dev: 
  https://github.com/zlotnika/b2tob3
  http://geeksta.net/tools/b2tob3-migrate-bootstrap/

My version added some more support:
- Extensions

    Style: '.css', '.haml', '.less'
    HTML: '.html', '.htm', '.js'
    Script files: '.jsp', '.jspf'
    Language: '.java', '.php' (Use it carefully)

- More Bootstrap 2 to 3 classes support
- FontAwesome version 3 to v4


How to Use
============================
Backup your original file
Put your template source files into some of the version control such as SVN or Git

Copy the b2tob3.exe into the same folder or put it as in Windows path and run on the expected folder:

> b2tob3.exe

And check if something to edit/revert.


Support/Contribute
============================
Source code: https://github.com/metrey/b2tob3
Let me know in my post at http://ask.osify.com/qa/589